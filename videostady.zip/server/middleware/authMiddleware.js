// server/middleware/authMiddleware.js
const jwt = require('jsonwebtoken');
const pool = require('../db');

const authMiddleware = async (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Требуется токен' });
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'secret_key');
    console.log('🔐 [auth] Токен:', decoded);

    const result = await pool.query(
      `SELECT id, username AS full_name, role_id AS role
       FROM videostady_user
       WHERE id = $1`,
      [decoded.id]
    );

    if (result.rows.length === 0) {
      return res.status(403).json({ message: 'Пользователь не существует' });
    }

    const user = result.rows[0];
    const role = Number(user.role);

    if (![1, 2].includes(role)) {
      return res.status(403).json({ message: 'Недопустимая роль' });
    }

    req.user = {
      id: user.id,
      role: role,
      full_name: user.full_name,
    };

    console.log('✅ [auth] Авторизован:', req.user);
    next();
  } catch (err) {
    if (err.name === 'JsonWebTokenError') {
      console.error('❌ Неверный токен');
      return res.status(403).json({ message: 'Неверный токен' });
    }
    if (err.name === 'TokenExpiredError') {
      console.error('❌ Токен истёк');
      return res.status(403).json({ message: 'Токен истёк' });
    }
    console.error('❌ [auth] Ошибка:', err);
    res.status(500).json({ message: 'Ошибка авторизации' });
  }
};

module.exports = authMiddleware;
