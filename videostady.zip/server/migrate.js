// server/migrate.js
const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_DATABASE,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,
});

// Список миграций — в порядке выполнения
const migrations = [
  '01_create_roles_and_users.sql',
  '01_create_calendar_table.sql',
];

async function runMigration() {
  const client = await pool.connect();
  try {
    for (const fileName of migrations) {
      const filePath = path.join(__dirname, 'migrations', fileName);
      console.log(`🔍 Читаем миграцию: ${fileName}`);

      if (!fs.existsSync(filePath)) {
        console.error(`❌ Файл не найден: ${filePath}`);
        process.exit(1);
      }

      const sql = fs.readFileSync(filePath, 'utf8');
      await client.query(sql);
      console.log(`✅ Миграция применена: ${fileName}`);
    }

    console.log('\n🎉 Все миграции успешно выполнены!');
  } catch (err) {
    console.error('❌ Ошибка при выполнении миграции:', err.stack);
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
    console.log('🔌 База данных отключена');
  }
}

runMigration();
