// server/controllers/calendarController.js
const pool = require('../db');

// GET /events/my — свои (или все для админа)
exports.getMyEvents = async (req, res) => {
  try {
    const { id: userId, role } = req.user;
    console.log('🔍 [getMyEvents] Пользователь:', { userId, role });

    let query, params = [];

    if (role === 2) {
      // Админ: все события
      query = `
        SELECT 
          id, title, description, event_date, start_time, end_time,
          organization, full_name, phone, email, user_id, created_at
        FROM videostady_calendar
        ORDER BY event_date DESC, start_time DESC
      `;
    } else {
      // Пользователь: только свои
      query = `
        SELECT 
          id, title, description, event_date, start_time, end_time,
          organization, full_name, phone, email, user_id, created_at
        FROM videostady_calendar
        WHERE user_id = $1
        ORDER BY event_date DESC, start_time DESC
      `;
      params = [userId];
    }

    const result = await pool.query(query, params);
    console.log(`✅ [getMyEvents] Найдено: ${result.rows.length}`);
    res.json(result.rows);
  } catch (err) {
    console.error('❌ [getMyEvents] Ошибка:', err);
    res.status(500).json({ message: 'Ошибка при загрузке событий' });
  }
};

// GET /events/:id — получить одно событие
exports.getEventById = async (req, res) => {
  const { id } = req.params;

  try {
    if (!/^\d+$/.test(id)) {
      return res.status(400).json({ message: 'Некорректный ID' });
    }

    const result = await pool.query(
      `SELECT 
         id, title, description, event_date, start_time, end_time,
         organization, full_name, phone, email, user_id, created_at
       FROM videostady_calendar
       WHERE id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Событие не найдено' });
    }

    console.log(`✅ [getEventById] Событие ${id} найдено`);
    res.json(result.rows[0]);
  } catch (err) {
    console.error('❌ [getEventById] Ошибка:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
};

// POST /events — создать событие
exports.createEvent = async (req, res) => {
  try {
    const { title, description, event_date, start_time, end_time, organization, full_name, phone, email } = req.body;
    const { id: user_id, role, full_name: userName } = req.user;

    console.log('📥 [createEvent] Тело:', req.body);
    console.log('👤 [createEvent] Пользователь:', { user_id, role, userName });

    if (![1, 2].includes(role)) {
      return res.status(403).json({ message: 'Доступ запрещён' });
    }

    if (!title || !event_date || !start_time || !end_time || !full_name) {
      return res.status(400).json({
        message: 'Обязательные поля: Наименование, Дата, Время, ФИО',
      });
    }

    const result = await pool.query(
      `INSERT INTO videostady_calendar
        (title, description, event_date, start_time, end_time, organization, full_name, phone, email, user_id, created_at)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW())
        RETURNING id, title, event_date, start_time, end_time, created_at`,
      [title, description, event_date, start_time, end_time, organization, full_name, phone, email, user_id]
    );

    console.log(`✅ [createEvent] Добавлено: ID=${result.rows[0].id}`);
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error('❌ [createEvent] Ошибка:', err);
    res.status(500).json({ message: 'Ошибка при добавлении события' });
  }
};

// PUT /events/:id — обновить событие
exports.updateEvent = async (req, res) => {
  const { id } = req.params;
  const { title, description, event_date, start_time, end_time, organization, full_name, phone, email } = req.body;
  const { id: userId, role } = req.user;

  try {
    if (!/^\d+$/.test(id)) {
      return res.status(400).json({ message: 'Некорректный ID' });
    }

    const eventResult = await pool.query('SELECT * FROM videostady_calendar WHERE id = $1', [id]);
    if (eventResult.rows.length === 0) {
      return res.status(404).json({ message: 'Событие не найдено' });
    }

    const event = eventResult.rows[0];
    if (event.user_id !== userId && role !== 2) {
      return res.status(403).json({ message: 'Нет прав на редактирование' });
    }

    const result = await pool.query(
      `UPDATE videostady_calendar SET
         title = $1, description = $2, event_date = $3, start_time = $4, end_time = $5,
         organization = $6, full_name = $7, phone = $8, email = $9
       WHERE id = $10
       RETURNING *`,
      [title, description, event_date, start_time, end_time, organization, full_name, phone, email, id]
    );

    // 🔽 Логирование отключено — нет таблицы event_logs
    // Если создадите таблицу — можно вернуть

    console.log(`✅ [updateEvent] Обновлено: ID=${id}`);
    res.json(result.rows[0]);
  } catch (err) {
    console.error('❌ [updateEvent] Ошибка:', err);
    res.status(500).json({ message: 'Ошибка при обновлении события' });
  }
};

// DELETE /events/:id
exports.deleteEvent = async (req, res) => {
  const { id } = req.params;
  const { id: userId, role } = req.user;

  try {
    if (!/^\d+$/.test(id)) {
      return res.status(400).json({ message: 'Некорректный ID' });
    }

    const result = await pool.query('SELECT * FROM videostady_calendar WHERE id = $1', [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Событие не найдено' });
    }

    if (role !== 2) {
      return res.status(403).json({ message: 'Только администратор может удалять' });
    }

    await pool.query('DELETE FROM videostady_calendar WHERE id = $1', [id]);

    // 🔽 Логирование отключено

    console.log(`✅ [deleteEvent] Событие ID=${id} удалено`);
    res.json({ message: 'Событие успешно удалено' });
  } catch (err) {
    console.error('❌ [deleteEvent] Ошибка:', err);
    res.status(500).json({ message: 'Ошибка при удалении события' });
  }
};
