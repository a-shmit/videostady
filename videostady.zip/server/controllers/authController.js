// server/controllers/authController.js
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../db');

// ✅ Регистрация
exports.register = async (req, res) => {
  const { username, password } = req.body;
  console.log('📥 Регистрация:', username);

  if (!username || !password) {
    return res.status(400).json({ message: 'Логин и пароль обязательны' });
  }

  if (password.length < 6) {
    return res.status(400).json({ message: 'Пароль должен быть не менее 6 символов' });
  }

  try {
    const existing = await pool.query(
      'SELECT * FROM videostady_user WHERE username = $1',
      [username]
    );

    if (existing.rows.length > 0) {
      return res.status(409).json({ message: 'Логин уже занят' });
    }

    const hashed = await bcrypt.hash(password, 10);

    const result = await pool.query(
      `INSERT INTO videostady_user (username, password) 
       VALUES ($1, $2) 
       RETURNING id, username`,
      [username, hashed]
    );

    const user = result.rows[0];
    const token = jwt.sign(
  { id: user.id, role: 1 }, // ✅ 1 — обычный пользователь
  process.env.JWT_SECRET,
  { expiresIn: '1h' }
    );

    res.status(201).json({ token, user });
  } catch (err) {
    console.error('❌ Ошибка регистрации:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
};

// ✅ Вход
exports.login = async (req, res) => {
  const { username, password } = req.body;
  console.log('📥 Вход:', username);

  if (!username || !password) {
    return res.status(400).json({ message: 'Логин и пароль обязательны' });
  }

  try {
    const result = await pool.query(
      'SELECT * FROM videostady_user WHERE username = $1',
      [username]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ message: 'Неверный логин или пароль' });
    }

    const user = result.rows[0];
    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
      return res.status(401).json({ message: 'Неверный логин или пароль' });
    }

    const token = jwt.sign(
      { id: user.id, role: 'user' },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );

    res.json({ token, user: { id: user.id, username: user.username } });
  } catch (err) {
    console.error('❌ Ошибка входа:', err);
    res.status(500).json({ message: 'Ошибка сервера' });
  }
};
