// server/models/User.js
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../db'); // Подключение к БД

class User {
  // Найти пользователя по логину
  static async findByUsername(username) {
    const result = await pool.query(
      `SELECT u.id, u.username, u.password, u.role_id, r.name AS role_name
       FROM videostady_user u
       JOIN videostady_role r ON u.role_id = r.id
       WHERE u.username = $1`,
      [username]
    );
    return result.rows[0] || null;
  }

  // Зарегистрировать нового пользователя (с ролью user по умолчанию)
  static async register(username, password) {
    const hashedPassword = await bcrypt.hash(password, 10);

    const result = await pool.query(
      `INSERT INTO videostady_user (username, password, role_id)
       VALUES ($1, $2, 1) RETURNING id, username, role_id`,
      [username, hashedPassword]
    );

    return result.rows[0];
  }

  // Сгенерировать JWT-токен
  static generateToken(user) {
    return jwt.sign(
      { id: user.id, role: user.role_name },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );
  }
}

module.exports = User;
