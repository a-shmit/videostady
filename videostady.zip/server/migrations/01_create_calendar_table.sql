-- Файл: server/migrations/01_create_calendar_table.sql

CREATE TABLE videostady_calendar (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  event_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  organization VARCHAR(255),
  full_name VARCHAR(255) NOT NULL,
  phone VARCHAR(20),
  email VARCHAR(100),

  user_id INTEGER NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

  -- Роль: 1 — обычный пользователь, 2 — админ/организатор
  role INTEGER DEFAULT 1 CHECK (role IN (1, 2))
);

-- Индекс для ускорения поиска по дате и роли
CREATE INDEX idx_calendar_event_date ON videostady_calendar(event_date);
CREATE INDEX idx_calendar_role ON videostady_calendar(role);
CREATE INDEX idx_calendar_user_id ON videostady_calendar(user_id);
