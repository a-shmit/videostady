-- Создание таблицы ролей
CREATE TABLE IF NOT EXISTS videostady_role (
  id SERIAL PRIMARY KEY,
  name VARCHAR(50) NOT NULL UNIQUE -- например: 'user', 'admin'
);

-- Добавляем роли по умолчанию
INSERT INTO videostady_role (name) VALUES ('user') ON CONFLICT (name) DO NOTHING;
INSERT INTO videostady_role (name) VALUES ('admin') ON CONFLICT (name) DO NOTHING;

-- Создание таблицы пользователей
CREATE TABLE IF NOT EXISTS videostady_user (
  id SERIAL PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role_id INT NOT NULL DEFAULT 1,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (role_id) REFERENCES videostady_role (id) ON DELETE RESTRICT
);
