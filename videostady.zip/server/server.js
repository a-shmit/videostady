// server/server.js
require('dotenv').config();

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const cookieParser = require('cookie-parser');

const app = express();

// === 🛡️ Глобальные обработчики ошибок ===
process.on('unhandledRejection', (err) => {
  console.error('🚨 Unhandled Rejection:', err);
  process.exit(1);
});

process.on('uncaughtException', (err) => {
  console.error('🚨 Uncaught Exception:', err);
  process.exit(1);
});

// === 🔌 Подключаем БД ===
require('./db');

// === 🛡️ Middleware ===
app.use(helmet({ crossOriginEmbedderPolicy: false }));
app.use(express.json({ limit: '10mb' }));
app.use(cookieParser());

// === 🌐 CORS — для разработки
app.use(cors({ origin: '*', credentials: true }));

// === 📝 Логирование запросов ===
app.use(morgan('dev'));

// === 🚻 Подключаем маршруты с отладкой ===

// authRoutes
try {
  const authRoutes = require('./routes/authRoutes');
  app.use('/api/v1/auth', authRoutes);
  console.log('✅ Маршрут /api/v1/auth — подключён');
} catch (err) {
  console.error('❌ Ошибка загрузки authRoutes:', err.message);
}

// calendarRoutes — с логом всех путей
try {
  const calendarRoutes = require('./routes/calendarRoutes');
  app.use('/api/v1/calendar', calendarRoutes);
  console.log('✅ Маршрут /api/v1/calendar — подключён');

  // 🔍 Показываем все зарегистрированные пути
  console.log('\n📬 Список маршрутов /api/v1/calendar:');
  calendarRoutes.stack.forEach((layer) => {
    if (layer.route) {
      const methods = Object.keys(layer.route.methods).join(', ').toUpperCase();
      console.log(`   ${methods} /api/v1/calendar${layer.route.path}`);
    }
  });
  console.log(''); // Пустая строка для читаемости
} catch (err) {
  console.error('❌ Ошибка загрузки calendarRoutes:', err.message);
  console.error('💡 Убедитесь, что файл server/routes/calendarRoutes.js существует');
}

// === 🧪 Главная страница ===
app.get('/', (req, res) => {
  res.send(`
    <h1>✅ Сервер запущен!</h1>
    <p>Регистрация: <code>POST /api/v1/auth/register</code></p>
    <p>Вход: <code>POST /api/v1/auth/login</code></p>
    <p>События: <code>GET /api/v1/calendar/events</code></p>
    <p>Событие по ID: <code>GET /api/v1/calendar/events/1</code></p>
    <p>Добавить: <code>POST /api/v1/calendar/events</code></p>
    <p>Обновить: <code>PUT /api/v1/calendar/events/:id</code></p>
    <p>Удалить: <code>DELETE /api/v1/calendar/events/:id</code></p>
    <p>Статус: <strong>Работает</strong></p>
  `);
});

// === 🛑 404 для всех остальных маршрутов ===
app.use((req, res) => {
  console.error(`🛑 404: ${req.method} ${req.url}`);
  res.status(404).json({ message: 'Маршрут не найден' });
});

// === ❗ Обработка ошибок ===
app.use((err, req, res, next) => {
  console.error('🚨 Ошибка сервера:', err.stack);
  res.status(500).json({ message: 'Внутренняя ошибка сервера' });
});

// === 🚀 Запуск сервера ===
const PORT = process.env.APP_PORT || 8084;
const server = app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n✅✅✅ СЕРВЕР УСПЕШНО ЗАПУЩЕН: http://10.50.20.1:${PORT}`);
  console.log(`   • GET     /`);
  console.log(`   • GET     /api/v1/calendar/events`);
  console.log(`   • GET     /api/v1/calendar/events/my`);
  console.log(`   • GET     /api/v1/calendar/events/:id`);
  console.log(`   • POST    /api/v1/calendar/events`);
  console.log(`   • PUT     /api/v1/calendar/events/:id`);
  console.log(`   • DELETE  /api/v1/calendar/events/:id`);
  console.log(`   • Логин и регистрация: /api/v1/auth/*`);
});

// 🔥 Обработка ошибки "порт занят"
server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`\n❌ Порт ${PORT} уже занят!`);
    process.exit(1);
  }
});
