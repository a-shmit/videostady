// server/routes/calendarRoutes.js
const express = require('express');
const router = express.Router();
const calendarController = require('../controllers/calendarController');
const authMiddleware = require('../middleware/authMiddleware');

// ✅ Получить события: все (админ) или свои (пользователь)
router.get('/events', authMiddleware, calendarController.getMyEvents);
router.get('/events/my', authMiddleware, calendarController.getMyEvents);

// ✅ Получить одно событие по ID
router.get('/events/:id', authMiddleware, calendarController.getEventById);

// ✅ Добавить событие
router.post('/events', authMiddleware, calendarController.createEvent);

// ✅ Обновить событие
router.put('/events/:id', authMiddleware, calendarController.updateEvent);

// ✅ Удалить событие
router.delete('/events/:id', authMiddleware, calendarController.deleteEvent);

module.exports = router;
