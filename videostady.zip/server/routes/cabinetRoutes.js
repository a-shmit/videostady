// server/routes/cabinetRoutes.js
const express = require('express');
const router = express.Router();

// Временный маршрут (позже добавим middleware auth)
router.get('/cabinet', (req, res) => {
  res.json({ message: 'Кабинет работает! Авторизация пока не проверяется.' });
});

module.exports = router;
