#!/bin/sh
exec npm run start