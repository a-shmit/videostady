// src/index.js
import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App.js'; // Добавляем расширение .js
import 'font-awesome/css/font-awesome.min.css'; // Импорт стилей Font Awesome
import 'bootstrap/dist/css/bootstrap.min.css'; // Подключение стилей Bootstrap
import 'react-toastify/dist/ReactToastify.css'; // ← Добавьте

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);