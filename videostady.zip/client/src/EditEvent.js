// src/EditEvent.js
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import './Cabinet.css'; // ← Подключаем стили

function EditEvent() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    event_date: '',
    start_time: '',
    end_time: '',
    organization: '',
    full_name: '',
    phone: '',
    email: '',
  });

  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchEvent = async () => {
      try {
        const res = await fetch(`http://help-school66.ru:8084/api/v1/calendar/events/${id}`, {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });

        if (res.ok) {
          const data = await res.json();
          setEvent(data);
          setFormData({
            title: data.title || '',
            description: data.description || '',
            event_date: data.event_date || '',
            start_time: data.start_time || '',
            end_time: data.end_time || '',
            organization: data.organization || '',
            full_name: data.full_name || '',
            phone: data.phone || '',
            email: data.email || '',
          });
        } else {
          alert('❌ Событие не найдено');
          navigate('/cabinet');
        }
      } catch (err) {
        alert('Ошибка подключения');
        navigate('/cabinet');
      } finally {
        setLoading(false);
      }
    };

    fetchEvent();
  }, [id, token, navigate]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const res = await fetch(`http://help-school66.ru:8084/api/v1/calendar/events/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(formData),
      });

      if (res.ok) {
        alert('✅ Событие обновлено');
        navigate(`/event/${id}`);
      } else if (res.status === 403) {
        alert('❌ Доступ запрещён');
      } else {
        alert('❌ Ошибка сервера при обновлении');
      }
    } catch (err) {
      alert('❌ Ошибка сети');
      console.error(err);
    }
  };

  if (loading) return <div className="event-detail-loading">Загрузка...</div>;
  if (!event) return null;

  return (
    <div className="edit-event-page">
      <div className="event-detail-header">
        <h1>Редактировать событие</h1>
      </div>

      <div className="event-detail-content">
        <div className="event-detail-actions">
          <button onClick={() => navigate(-1)} className="btn btn-back">← Назад</button>
        </div>

        <div className="event-detail-card">
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Наименование</label>
              <input
                name="title"
                value={formData.title}
                onChange={handleChange}
                placeholder="Наименование"
                required
              />
            </div>

            <div className="form-group">
              <label>Описание</label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleChange}
                placeholder="Описание"
              />
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>Дата</label>
                <input
                  name="event_date"
                  type="date"
                  value={formData.event_date}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="form-group">
                <label>Начало</label>
                <input
                  name="start_time"
                  type="time"
                  value={formData.start_time}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="form-group">
                <label>Конец</label>
                <input
                  name="end_time"
                  type="time"
                  value={formData.end_time}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>

            <div className="form-group">
              <label>Организация</label>
              <input
                name="organization"
                value={formData.organization}
                onChange={handleChange}
                placeholder="Организация"
              />
            </div>

            <div className="form-group">
              <label>Ф.И.О.</label>
              <input
                name="full_name"
                value={formData.full_name}
                onChange={handleChange}
                placeholder="Ф.И.О."
                required
              />
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>Телефон</label>
                <input
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="Телефон"
                />
              </div>

              <div className="form-group">
                <label>Email</label>
                <input
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="Email"
                />
              </div>
            </div>

            <button type="submit" className="btn btn-edit">💾 Сохранить</button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default EditEvent;
