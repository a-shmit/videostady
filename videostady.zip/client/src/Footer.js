// Footer.js
function Footer() {
  return (
    <footer className="App-footer">
      <h2>Свяжитесь с нами</h2>
      <p>Телефон: +7 (XXX) XXX-XX-XX</p>
      <p>Email: info@example.com</p>
      <button>Забронировать </button>
    </footer>
  );
}

export default Footer;
