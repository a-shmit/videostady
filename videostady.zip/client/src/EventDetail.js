// src/EventDetail.js
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function EventDetail() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(true);

  const token = localStorage.getItem('token');
  let userRole = null;

  // === Парсинг токена ===
  if (token) {
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      console.log('🔍 [EventDetail] payload:', payload); // Для отладки

      // 🔑 Берём role и приводим к числу
      userRole = Number(payload.role);

      // 🔥 Если нужно — принудительно: только 2
      // userRole = Number(payload.role) === 2 ? 2 : 1;
    } catch (err) {
      console.error('❌ Ошибка токена:', err);
    }
  }

  useEffect(() => {
    if (!token) {
      toast.error('Требуется авторизация');
      navigate('/login', { replace: true });
      return;
    }

    const fetchEvent = async () => {
      setLoading(true);
      try {
        const res = await fetch(`http://help-school66.ru:8084/api/v1/calendar/events/${id}`, {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });

        if (res.ok) {
          const data = await res.json();
          setEvent(data);
        } else if (res.status === 404) {
          toast.error('Событие не найдено');
          setTimeout(() => navigate('/cabinet'), 1500);
        } else if (res.status === 403) {
          toast.error('Доступ запрещён');
          setTimeout(() => navigate('/cabinet'), 1500);
        } else {
          toast.error('Ошибка загрузки события');
        }
      } catch (err) {
        console.error('❌ Сеть:', err);
        toast.error('Ошибка подключения');
      } finally {
        setLoading(false);
      }
    };

    fetchEvent();
  }, [id, token, navigate]);

  // === Удаление ===
  const handleDelete = async () => {
    if (!window.confirm('Вы уверены, что хотите удалить это событие?')) return;

    try {
      const res = await fetch(`http://help-school66.ru:8084/api/v1/calendar/events/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (res.ok) {
        toast.success('✅ Событие удалено');
        setTimeout(() => navigate('/cabinet'), 1000);
      } else if (res.status === 403) {
        toast.error('❌ Нет прав');
      } else {
        toast.error('❌ Ошибка');
      }
    } catch (err) {
      toast.error('❌ Ошибка сети');
    }
  };

  // === Назад ===
  const goBack = () => {
    if (window.history.length > 1) navigate(-1);
    else navigate('/cabinet');
  };

  if (loading) return <div className="event-detail-loading">Загрузка...</div>;
  if (!event) return <div className="event-detail-error">Событие не найдено</div>;

  return (
    <div className="event-detail-page">
      <ToastContainer position="top-right" autoClose={3000} />

      <div className="event-detail-header">
        <h1>Детали события</h1>
      </div>

      <div className="event-detail-content">
        <div className="event-detail-actions">
          <button type="button" onClick={goBack} className="btn btn-back">← Назад</button>
          <button type="button" onClick={() => navigate(`/event/${id}/edit`)} className="btn btn-edit">📝 Редактировать</button>

          {/* ✅ КНОПКА УДАЛИТЬ: только если role = 2 */}
          {userRole === 2 && (
            <button type="button" onClick={handleDelete} className="btn btn-delete">🗑️ Удалить</button>
          )}
        </div>

        <div className="event-detail-card">
          <h2>{event.title}</h2>
          <div className="event-detail-info">
            <p><strong>Дата:</strong> {event.event_date.split('T')[0]}</p>
            <p><strong>Время:</strong> {event.start_time} – {event.end_time}</p>
            <p><strong>Описание:</strong> {event.description || '—'}</p>
            <p><strong>Организация:</strong> {event.organization || '—'}</p>
            <p><strong>ФИО:</strong> {event.full_name}</p>
            <p><strong>Телефон:</strong> {event.phone || '—'}</p>
            <p><strong>Email:</strong> {event.email || '—'}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default EventDetail;
