// src/Login.js
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './App.css';

function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    // Валидация
    if (!username.trim()) {
      setError('empty-username');
      setLoading(false);
      return;
    }
    if (password.length < 6) {
      setError('short-password');
      setLoading(false);
      return;
    }

    try {
      const response = await fetch('http://help-school66.ru:8084/api/v1/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
      });

      const data = await response.json();

      if (response.ok) {
        localStorage.setItem('token', data.token);
        window.location.href = '/cabinet';
      } else {
        setError('invalid-credentials');
      }
    } catch (err) {
      setError('network-error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-form">
        <h2>Вход в систему</h2>

        {/* Унифицированное сообщение об ошибке (стиль из App.css) */}
        {error && (
          <div className={`error-message ${error}`}>
            {error === 'empty-username' && 'Введите логин'}
            {error === 'short-password' && 'Пароль должен быть не менее 6 символов'}
            {error === 'invalid-credentials' && 'Неверный логин или пароль'}
            {error === 'network-error' && 'Ошибка подключения к серверу. Проверьте соединение.'}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="username">Логин:</label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Введите логин"
              autoComplete="username"
              disabled={loading}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Пароль:</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Введите пароль"
              autoComplete="current-password"
              disabled={loading}
              required
            />
          </div>

          <button type="submit" disabled={loading}>
            {loading ? 'Вход...' : 'Войти'}
          </button>

          <p className="register-link">
            Нет аккаунта? <Link to="/register">Зарегистрироваться</Link>
          </p>
        </form>
      </div>
    </div>
  );
}

export default Login;
