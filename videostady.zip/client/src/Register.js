// src/Register.js
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './App.css';

function Register() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [showSuccess, setShowSuccess] = useState(false);     // Уведомление об успехе
  const [showCountdown, setShowCountdown] = useState(false); // Уведомление с таймером
  const [countdown, setCountdown] = useState(0);             // Счётчик: 3, 2, 1
  const [loading, setLoading] = useState(false);             // Блокировка формы

  const API_URL = 'http://help-school66.ru:8084';

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setShowSuccess(false);
    setShowCountdown(false);
    setCountdown(0);

    if (!username.trim()) {
      return setError('Введите логин');
    }
    if (password.length < 6) {
      return setError('Пароль должен быть не менее 6 символов');
    }
    if (password !== confirmPassword) {
      return setError('Пароли не совпадают');
    }

    setLoading(true);

    try {
      const response = await fetch(`${API_URL}/api/v1/auth/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
      });

      const data = await response.json();

      if (response.ok) {
        // 1. Показать уведомление об успешной регистрации
        setShowSuccess(true);

        // Сохранить токен
        localStorage.setItem('token', data.token);

        // 2. Запустить таймер и показать второе уведомление
        setCountdown(3);
        setShowCountdown(true);

        let timer = 3;
        const interval = setInterval(() => {
          timer -= 1;
          setCountdown(timer);
          if (timer === 0) {
            clearInterval(interval);
            window.location.href = '/cabinet';
          }
        }, 1000);
      } else {
        setError(data.message || 'Регистрация не удалась');
      }
    } catch (err) {
      setError('Не удалось подключиться к серверу. Проверьте соединение.');
      console.error('Ошибка:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-form">
        <h2>Регистрация</h2>

        {/* Ошибка */}
        {error && (
          <div
            style={{
              color: '#d32f2f',
              fontSize: '14px',
              backgroundColor: '#ffebee',
              padding: '12px',
              borderRadius: '8px',
              marginBottom: '16px',
              border: '1px solid #ffcdd2',
            }}
          >
            {error}
          </div>
        )}

        {/* Уведомление 1: Успешная регистрация */}
        {showSuccess && (
          <div
            style={{
              color: '#2e7d32',
              fontSize: '14px',
              backgroundColor: '#f3fff3',
              padding: '12px',
              borderRadius: '8px',
              marginBottom: '16px',
              border: '1px solid #c8e6c9',
            }}
          >
            ✅ <strong>Пользователь успешно зарегистрирован!</strong>
          </div>
        )}

        {/* Уведомление 2: Таймер перенаправления */}
        {showCountdown && (
          <div
            style={{
              color: '#1976d2',
              fontSize: '14px',
              backgroundColor: '#e3f2fd',
              padding: '12px',
              borderRadius: '8px',
              marginBottom: '16px',
              border: '1px solid #bbdefb',
            }}
          >
            🕒 Вы будете автоматически перенаправлены в кабинет через: <strong>{countdown}</strong> секунд...
          </div>
        )}

        {/* Форма (блокируется после отправки) */}
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="username">Логин</label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Введите логин"
              autoComplete="username"
              disabled={loading || showCountdown}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Пароль</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Введите пароль"
              autoComplete="new-password"
              disabled={loading || showCountdown}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="confirmPassword">Подтвердите пароль</label>
            <input
              type="password"
              id="confirmPassword"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Повторите пароль"
              autoComplete="new-password"
              disabled={loading || showCountdown}
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading || showCountdown}
            style={{
              opacity: loading || showCountdown ? 0.6 : 1,
              cursor: loading || showCountdown ? 'not-allowed' : 'pointer',
            }}
          >
            {loading
              ? 'Регистрация...'
              : showCountdown
              ? `Переход... (${countdown})`
              : 'Зарегистрироваться'}
          </button>

          <p className="register-link">
            Уже есть аккаунт? <Link to="/login">Войти</Link>
          </p>
        </form>
      </div>
    </div>
  );
}

export default Register;
