// src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Header from './Header.js';
import Footer from './Footer.js';
import Login from './Login.js';
import Register from './Register.js';
import Cabinet from './Cabinet.js';
import EventDetail from './EventDetail.js';
import EditEvent from './EditEvent.js';
import './App.css';

// === Изображения — только существующие файлы ===
import image1 from './images/1244f14eb79ca6d791f41daacc9ccad6.jpeg';
import image2 from './images/c2eef3b85587bf52fbe56b359cc5a5a5.jpeg';
import image3 from './images/eccc486bc2d4d1f24d4df9dda233a53e.jpeg';
import image4 from './images/minobr_logo.png';
import image6 from './images/bb54b1b0-c112-4d45-a503-60c486d5d6a0.png';
import image7 from './images/orig.jpg';

// Если image8 не существует — не импортируем! Используем image7 как дубль, если нужно
// Убрали: import image8 from './images/...'; → вызывал ошибку

// === 🔐 Защищённый маршрут ===
function ProtectedRoute({ children }) {
  const token = localStorage.getItem('token');
  return token ? children : <Navigate to="/login" replace />;
}

// === 🏠 Главная страница ===
function HomePage() {
  return (
    <>
      <section className="about">
        <div className="banner">
          <div className="banner-content">
            <h2>Видеостудия ЦАД СПО "Электронный колледж"</h2>
            <p>Это создание образовательного контента для онлайн обучения, видео-конференции.</p>
            <button className="event-button">Забронировать</button>
          </div>
        </div>
      </section>

      <section className="services">
        <h2>Из чего состоит видеостудия</h2>
        <div className="service-blocks">
          <div className="service-block">
            <div className="service-icon-container">
              <i className="fa fa-television" aria-hidden="true"></i>
            </div>
            <div className="service-text">
              <h3>Интерактивная сенсорная доска</h3>
              <p>Стеклянная сенсорная доска от 85 до 93 дюймов. Взаимодействие пальцами и бесцветным маркером.</p>
            </div>
          </div>
          <div className="service-block">
            <div className="service-icon-container">
              <i className="fa fa-video-camera" aria-hidden="true"></i>
            </div>
            <div className="service-text">
              <h3>Видео и звук</h3>
              <p>Камера с возможностью записи видео с частотой от 30 до 60 кадров/сек, Full HD и 4К. Петличный микрофон с возможностью одновременной записи двух спикеров и общим зарядный кейсом.</p>
            </div>
          </div>
          <div className="service-block">
            <div className="service-icon-container">
              <i className="fa fa-laptop" aria-hidden="true"></i>
            </div>
            <div className="service-text">
              <h3>Оборудование</h3>
              <p>Точки освещения, проектор, экран, мониторы, сервер, фоны, шторы blackout, стойки крепления, телесуфлер.</p>
            </div>
          </div>
        </div>

        <div className="service-carousel">
          <div className="service-item">
            <img src={image1} alt="Услуга 1" />
          </div>
          <div className="service-item">
            <img src={image2} alt="Услуга 2" />
          </div>
          <div className="service-item">
            <img src={image3} alt="Услуга 3" />
          </div>
        </div>

        <h2>Стоимость аренды видеостудии с простым монтажом</h2>
        <div className="price-blocks">
          <div className="price-block">
            <h3>10 часов аренды студии</h3>
            <div className="price-block-separator"></div>
            <p>4 500 руб./ч.</p>
          </div>
          <div className="price-block">
            <h3>от 10 до 40 часов аренды студии</h3>
            <div className="price-block-separator"></div>
            <p>3 500 руб./ч.</p>
          </div>
          <div className="price-block">
            <h3>свыше 40 часов аренды</h3>
            <div className="price-block-separator"></div>
            <p>3 100 руб./ч.</p>
          </div>
        </div>
      </section>

      <section className="portfolio">
        <div className="portfolio-slider">
          <div className="portfolio-item">
            <iframe
              src="https://vk.ru/video_ext.php?oid=-211812539&id=456239235&autoplay=1"
              width="1280"
              height="720"
              style={{ backgroundColor: '#000' }}
              allow="autoplay; encrypted-media; fullscreen; picture-in-picture; screen-wake-lock;"
              frameBorder="0"
              allowFullScreen
            ></iframe>
          </div>
          <div className="portfolio-item">
            <video src="video2.mp4" controls style={{ width: '100%' }}></video>
          </div>
        </div>
      </section>

      <section className="partners">
        <h2>Наши партнеры</h2>
        <div className="partners-logos">
          <img src={image4} alt="Министерство образования Свердловской области" />
          <img src={image6} alt="Институт развития образования" />
          <img src={image7} alt="ЦОПП" />
          {/* 
            ❌ Убрано image8 — файла нет, ошибка при сборке.
            ✅ Добавьте, если есть: image8.jpg/png в папку src/images/
          */}
        </div>
      </section>
    </>
  );
}

// === 🧱 Основной App ===
function App() {
  return (
    <Router>
      <div className="app-container">
        <Header />
        <main className="main-content">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />

            <Route
              path="/cabinet"
              element={
                <ProtectedRoute>
                  <Cabinet />
                </ProtectedRoute>
              }
            />

            <Route
              path="/event/:id"
              element={
                <ProtectedRoute>
                  <EventDetail />
                </ProtectedRoute>
              }
            />

            <Route
              path="/event/:id/edit"
              element={
                <ProtectedRoute>
                  <EditEvent />
                </ProtectedRoute>
              }
            />

            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
