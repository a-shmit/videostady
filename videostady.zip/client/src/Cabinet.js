// src/Cabinet.js
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import './Cabinet.css';

function Cabinet() {
  const [activeTab, setActiveTab] = useState('events');
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [userRole, setUserRole] = useState(null);
  const [selectedDate, setSelectedDate] = useState(new Date());

  const navigate = useNavigate();

  // ✅ Полный URL к API
  const API_BASE = 'http://help-school66.ru:8084/api/v1/calendar';

  // === Получение роли из токена ===
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      setError('Требуется авторизация');
      setLoading(false);
      return;
    }

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      console.log('🔐 [Cabinet] Токен:', payload);

      const role = payload.role === 'admin'
        ? 2
        : payload.role === 'user'
          ? 1
          : Number(payload.role);

      if (![1, 2].includes(role)) {
        setError('Недопустимая роль');
      } else {
        setUserRole(role);
      }
    } catch (err) {
      console.error('❌ Ошибка разбора токена:', err);
      setError('Ошибка авторизации');
    } finally {
      setLoading(false);
    }
  }, []);

  // === Загрузка событий ===
  useEffect(() => {
    if ((activeTab === 'events' || activeTab === 'calendar') && userRole !== null) {
      fetchEvents();
    }
  }, [activeTab, userRole]);

  const fetchEvents = async () => {
    setLoading(true);
    setError('');

    const url = userRole === 2
      ? `${API_BASE}/events`
      : `${API_BASE}/events/my`;

    console.log('🚀 [Cabinet] Запрос событий:', url);

    try {
      const res = await fetch(url, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
      });

      if (res.ok) {
        const data = await res.json();
        setEvents(Array.isArray(data) ? data : []);
      } else if (res.status === 401) {
        setError('Сессия истекла');
        navigate('/login');
      } else if (res.status === 403) {
        setError('Доступ запрещён');
      } else {
        const text = await res.text();
        console.error('❌ [fetchEvents] Ошибка сервера:', text);
        setError('Не удалось загрузить события');
      }
    } catch (err) {
      console.error('❌ [Cabinet] Ошибка сети:', err);
      setError('Ошибка подключения к серверу');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="cabinet-layout">
      <nav className="cabinet-sidebar">
        <h3>Меню</h3>
        <ul>
          <li>
            <button
              className={activeTab === 'events' ? 'active' : ''}
              onClick={() => setActiveTab('events')}
            >
              Все события
            </button>
          </li>
          <li>
            <button
              className={activeTab === 'calendar' ? 'active' : ''}
              onClick={() => setActiveTab('calendar')}
            >
              Календарь
            </button>
          </li>
          <li>
            <button
              className={activeTab === 'add' ? 'active' : ''}
              onClick={() => setActiveTab('add')}
            >
              Добавить событие
            </button>
          </li>
        </ul>
      </nav>

      <main className="cabinet-content">
        {error && <div className="error-message">{error}</div>}
        {activeTab === 'events' && <AllEventsTab events={events} loading={loading} navigate={navigate} />}
        {activeTab === 'calendar' && (
          <CalendarTab 
            events={events} 
            selectedDate={selectedDate} 
            setSelectedDate={setSelectedDate} 
            navigate={navigate} 
          />
        )}
        {activeTab === 'add' && <AddEventTab onEventAdded={() => setActiveTab('events')} />}
      </main>
    </div>
  );
}

// === Все события ===
function AllEventsTab({ events, loading, navigate }) {
  if (loading) return <p>Загрузка событий...</p>;
  if (events.length === 0) return <p>Событий пока нет</p>;

  return (
    <div className="events-list">
      <h2>Все события</h2>
      {events.map((event) => (
        <div
          key={event.id}
          className="event-card"
          onClick={() => navigate(`/event/${event.id}`)}
          style={{ cursor: 'pointer' }}
        >
          <h3>{event.title}</h3>
          <p>
            <strong>Дата:</strong> {event.event_date.split('T')[0]} | 
            <strong>Время:</strong> {event.start_time} – {event.end_time}
          </p>
          <p><strong>Организация:</strong> {event.organization || '—'}</p>
          <p><strong>ФИО:</strong> {event.full_name}</p>
        </div>
      ))}
    </div>
  );
}

// === Календарь: исправлено отображение и клик ===
function CalendarTab({ events, selectedDate, setSelectedDate, navigate }) {
  // ✅ Группируем события по дате
  const eventsByDate = events.reduce((acc, event) => {
    const dateKey = event.event_date ? event.event_date.split('T')[0] : null;
    if (!dateKey) return acc;
    if (!acc[dateKey]) acc[dateKey] = [];
    acc[dateKey].push(event);
    return acc;
  }, {});

  // ✅ Есть ли события на дату?
  const hasEventOnDate = (date) => {
    const dateString = date.toISOString().split('T')[0];
    return eventsByDate[dateString] && eventsByDate[dateString].length > 0;
  };

  // ✅ События на выбранную дату
  const selectedDateString = selectedDate.toISOString().split('T')[0];
  const eventsOnSelectedDate = eventsByDate[selectedDateString] || [];

  return (
    <div className="calendar-tab">
      <h2>Календарь событий</h2>
      <div className="calendar-split-layout">
        <div className="calendar-left">
          <Calendar
            onChange={setSelectedDate}
            value={selectedDate}
            locale="ru"
            onClickDay={setSelectedDate}
            tileContent={({ date, view }) => {
              if (view === 'month' && hasEventOnDate(date)) {
                return <div className="event-dot"></div>;
              }
              return null;
            }}
            formatDay={(locale, date) => date.getDate()}
          />
        </div>
        <div className="events-right">
          <div className="events-sidebar">
            <h3>
              События на{' '}
              {selectedDate.toLocaleDateString('ru-RU', {
                day: '2-digit',
                month: 'long',
                year: 'numeric',
              })}
            </h3>
            {eventsOnSelectedDate.length > 0 ? (
              <ul>
                {eventsOnSelectedDate.map((event) => (
                  <li
                    key={event.id}
                    className="event-item"
                    onClick={() => navigate(`/event/${event.id}`)}
                    style={{ cursor: 'pointer' }}
                  >
                    <strong>{event.title}</strong>
                    <br />
                    <small>{event.start_time} – {event.end_time}</small>
                    <br />
                    <small><strong>Организация:</strong> {event.organization || '—'}</small>
                    <br />
                    <small><strong>ФИО:</strong> {event.full_name}</small>
                  </li>
                ))}
              </ul>
            ) : (
              <p>На эту дату нет событий</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// === Форма добавления ===
function AddEventTab({ onEventAdded }) {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    event_date: '',
    start_time: '',
    end_time: '',
    organization: '',
    full_name: '',
    phone: '',
    email: '',
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();

    console.log('📤 [AddEvent] Отправляю:', formData);

    setLoading(true);
    try {
      const res = await fetch('http://help-school66.ru:8084/api/v1/calendar/events', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify(formData),
      });

      console.log('📡 [AddEvent] Статус:', res.status);

      if (res.ok) {
        console.log('✅ Событие добавлено');
        onEventAdded();
      } else {
        const text = await res.text();
        console.error('❌ [AddEvent] Ошибка:', text);
        try {
          const json = JSON.parse(text);
          alert(json.message || 'Ошибка при добавлении');
        } catch {
          alert('Ошибка сервера');
        }
      }
    } catch (err) {
      console.error('❌ [AddEvent] Ошибка:', err);
      alert('Ошибка подключения (см. консоль)');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="add-event-form">
      <h2>Добавить событие</h2>
      <input
        placeholder="Наименование"
        value={formData.title}
        onChange={(e) => setFormData({ ...formData, title: e.target.value })}
        required
      />
      <textarea
        placeholder="Описание"
        value={formData.description}
        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
      />
      <input
        type="date"
        value={formData.event_date}
        onChange={(e) => setFormData({ ...formData, event_date: e.target.value })}
        required
      />
      <div className="time-row">
        <input
          type="time"
          value={formData.start_time}
          onChange={(e) => setFormData({ ...formData, start_time: e.target.value })}
          required
        />
        <span> — </span>
        <input
          type="time"
          value={formData.end_time}
          onChange={(e) => setFormData({ ...formData, end_time: e.target.value })}
          required
        />
      </div>
      <input
        placeholder="Организация"
        value={formData.organization}
        onChange={(e) => setFormData({ ...formData, organization: e.target.value })}
      />
      <input
        placeholder="Ф.И.О."
        value={formData.full_name}
        onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
        required
      />
      <input
        placeholder="Телефон"
        value={formData.phone}
        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
      />
      <input
        placeholder="Email"
        value={formData.email}
        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
      />
      <button type="submit" disabled={loading}>
        {loading ? 'Отправка...' : 'Добавить'}
      </button>
    </form>
  );
}

export default Cabinet;
