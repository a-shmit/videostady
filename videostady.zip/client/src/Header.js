// src/Header.js
import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import logo from './logo2.png'; // ✅ Правильный путь
import './App.css';

function Header() {
  const token = localStorage.getItem('token');
  const location = useLocation(); // ← Определяем текущий маршрут
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/'); // Перенаправляем на главную
    // window.location.reload() — убрано: обычно не нужно
  };

  return (
    <header className="App-header">
      <div className="header-content">
        {/* Логотип — ссылка на главную */}
        <Link to="/" className="logo-link">
          <img src={logo} alt="Логотип Видеостудии" className="logo" />
        </Link>

        {/* Кнопка в зависимости от токена и маршрута */}
        {token ? (
          // Пользователь авторизован
          location.pathname === '/cabinet' ? (
            // Находится в кабинете → кнопка "Выход"
            <button onClick={handleLogout} className="auth-button logout-button">
              Выход
            </button>
          ) : (
            // На главной или других страницах → "Личный кабинет"
            <Link to="/cabinet" className="auth-button">
              Личный кабинет
            </Link>
          )
        ) : (
          // Не авторизован
          <Link to="/login" className="auth-button login-button">
            Вход
          </Link>
        )}
      </div>
    </header>
  );
}

export default Header;
