
// src/MyCalendar.js
import React, { useState, useMemo } from 'react';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import './Calendar.css'; // Для своих стилей

function MyCalendar({ events }) {
  const [value, setValue] = useState(new Date());

  // Группируем события по датам
  const eventsByDate = useMemo(() => {
    const grouped = {};
    events.forEach(event => {
      const date = event.event_date; // '2025-04-05'
      if (!grouped[date]) grouped[date] = [];
      grouped[date].push(event);
    });
    return grouped;
  }, [events]);

  // Проверяем, есть ли события на дату
  const hasEvent = (date) => {
    const dateString = date.toISOString().split('T')[0]; // '2025-04-05'
    return eventsByDate[dateString];
  };

  const handleDayClick = (date) => {
    setValue(date);
  };

  const selectedDateEvents = hasEvent(value) || [];

  return (
    <div className="calendar-section">
      <h3>Календарь бронирований</h3>
      <div className="calendar-wrapper">
        <Calendar
          onChange={setValue}
          value={value}
          tileContent={({ date, view }) => {
            if (view === 'month') {
              const events = hasEvent(date);
              if (events) {
                return (
                  <div className="event-dot-container">
                    <div className="event-dot"></div>
                  </div>
                );
              }
            }
            return null;
          }}
          onClickDay={handleDayClick}
          locale="ru"
        />
      </div>

      <div className="selected-date-events">
        <h4>
          События на{' '}
          {value.toLocaleDateString('ru-RU', {
            day: '2-digit',
            month: 'long',
            year: 'numeric',
          })}
        </h4>

        {selectedDateEvents.length > 0 ? (
          <ul>
            {selectedDateEvents.map((event) => (
              <li key={event.id} className="event-item">
                <strong>{event.title}</strong>
                <br />
                <small>
                  {event.start_time} – {event.end_time} | {event.full_name}
                </small>
              </li>
            ))}
          </ul>
        ) : (
          <p>На эту дату нет событий</p>
        )}
      </div>
    </div>
  );
}

export default MyCalendar;
